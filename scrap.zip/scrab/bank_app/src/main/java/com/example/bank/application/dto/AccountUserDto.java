
package com.example.bank.application.dto;


import lombok.Data;

import java.util.Date;

@Data
public class AccountUserDto {

    String accountName;
    String accountPassword;
    Double initialDeposit = 0D;
    
//    private Long id;
//
//    private String name;
//
//    private String username;
//
//    private String email;
//
//    private String phoneNumber;
//
//    private String gender;
//
//    private Date dateOfBirth;
//
//    private String address;
//
//    private String streetNumber;
//
//    private Double amount;
//
//    private String password;

    
}
