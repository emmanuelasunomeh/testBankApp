package com.example.bank.application.enumeration;

/**
 * @author: Emmanuel Asunomeh
 * @Date: 8/21/2021
 */

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL;
}